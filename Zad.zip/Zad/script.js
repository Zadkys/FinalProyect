class Arista {
    constructor(destino, peso) {
        this.destino = destino;
        this.peso = peso;
    }
}

class Grafo {
    constructor(vertices) {
        this.adyacencia = [];
        for (let i = 0; i < vertices; i++) {
            this.adyacencia.push([]);
        }
    }

    agregarArista(origen, destino, peso) {
        this.adyacencia[origen].push(new Arista(destino, peso));
    }

    distanciaMinima(distancias, visitado) {
        let min = Infinity, minIndex = -1;
        for (let v = 0; v < distancias.length; v++) {
            if (!visitado[v] && distancias[v] <= min) {
                min = distancias[v];
                minIndex = v;
            }
        }
        return minIndex;
    }

    dijkstra(origen, destino) {
        let V = this.adyacencia.length;
        let distancias = new Array(V).fill(Infinity);
        let padres = new Array(V).fill(-1);
        let visitado = new Array(V).fill(false);
        distancias[origen] = 0;

        for (let count = 0; count < V - 1; count++) {
            let u = this.distanciaMinima(distancias, visitado);
            visitado[u] = true;

            for (let arista of this.adyacencia[u]) {
                if (!visitado[arista.destino] && distancias[u] !== Infinity &&
                    distancias[u] + arista.peso < distancias[arista.destino]) {
                    distancias[arista.destino] = distancias[u] + arista.peso;
                    padres[arista.destino] = u;
                }
            }
        }

        return { ruta: this.reconstruirRuta(padres, origen, destino), peso: distancias[destino] };
    }

    reconstruirRuta(padres, origen, destino) {
        let ruta = [];
        let actual = destino;
        while (actual !== -1) {
            ruta.push(actual);
            actual = padres[actual];
        }
        ruta.reverse();
        return ruta;
    }

    imprimirListaAdyacencia() {
        let container = document.getElementById('grafo-container');
        container.innerHTML = '';
        let vertices = 'ABCDEF';
        let posiciones = [
            {left: 50, top: 50},
            {left: 400, top: 50},
            {left: 400, top: 400},
            {left: 50, top: 400},
            {left: 225, top: 225},
            {left: 225, top: 50}
        ];

        for (let i = 0; i < this.adyacencia.length; i++) {
            let verticeDiv = document.createElement('div');
            verticeDiv.className = 'vertice';
            verticeDiv.innerText = vertices[i];
            verticeDiv.style.left = posiciones[i].left + 'px';
            verticeDiv.style.top = posiciones[i].top + 'px';
            container.appendChild(verticeDiv);
        }

        for (let i = 0; i < this.adyacencia.length; i++) {
            let verticeDiv = container.children[i];
            for (let arista of this.adyacencia[i]) {
                let aristaDiv = document.createElement('div');
                aristaDiv.className = 'arista';
                let destinoVertice = container.children[arista.destino];
                let x1 = verticeDiv.offsetLeft + 25;
                let y1 = verticeDiv.offsetTop + 25;
                let x2 = destinoVertice.offsetLeft + 25;
                let y2 = destinoVertice.offsetTop + 25;
                let length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
                let angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
                aristaDiv.style.width = length + 'px';
                aristaDiv.style.transform = `rotate(${angle}deg)`;
                aristaDiv.style.left = x1 + 'px';
                aristaDiv.style.top = y1 + 'px';

                // Añadir etiqueta de peso
                let pesoDiv = document.createElement('div');
                pesoDiv.className = 'peso-arista';
                pesoDiv.innerText = arista.peso;
                let pesoX = (x1 + x2) / 2;
                let pesoY = (y1 + y2) / 2;
                pesoDiv.style.left = pesoX + 'px';
                pesoDiv.style.top = pesoY + 'px';

                container.appendChild(aristaDiv);
                container.appendChild(pesoDiv);
            }
        }
    }

    resaltarCamino(ruta) {
        let container = document.getElementById('grafo-container');
        for (let i = 0; i < ruta.length - 1; i++) {
            let origen = ruta[i];
            let destino = ruta[i + 1];
            let origenDiv = container.children[origen];
            let destinoDiv = container.children[destino];
            let x1 = origenDiv.offsetLeft + 25;
            let y1 = origenDiv.offsetTop + 25;
            let x2 = destinoDiv.offsetLeft + 25;
            let y2 = destinoDiv.offsetTop + 25;
            let length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
            let angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
            let aristaDiv = document.createElement('div');
            aristaDiv.className = 'arista arista-camino';
            aristaDiv.style.width = length + 'px';
            aristaDiv.style.transform = `rotate(${angle}deg)`;
            aristaDiv.style.left = x1 + 'px';
            aristaDiv.style.top = y1 + 'px';

            container.appendChild(aristaDiv);
        }
    }
}

let grafo = new Grafo(6);
grafo.agregarArista(0, 1, 2);
grafo.agregarArista(0, 5, 1);
grafo.agregarArista(1, 0, 2);
grafo.agregarArista(1, 2, 2);
grafo.agregarArista(1, 3, 2);
grafo.agregarArista(1, 4, 4);
grafo.agregarArista(2, 1, 2);
grafo.agregarArista(2, 4, 3);
grafo.agregarArista(3, 1, 2);
grafo.agregarArista(3, 4, 4);
grafo.agregarArista(3, 5, 3);
grafo.agregarArista(4, 2, 3);
grafo.agregarArista(4, 3, 4);
grafo.agregarArista(5, 0, 1);
grafo.agregarArista(5, 3, 3);
grafo.agregarArista(5, 4, 5);

grafo.imprimirListaAdyacencia();

let origen = 1, destino = 3;
let resultado = grafo.dijkstra(origen, destino);
let rutaMinima = resultado.ruta;
let pesoTotal = resultado.peso;

grafo.resaltarCamino(rutaMinima);
document.getElementById('resultado').innerText = `Ruta mínima desde A hasta D: ${rutaMinima.map(i => String.fromCharCode(65 + i)).join(' -> ')} con peso total: ${pesoTotal}`;